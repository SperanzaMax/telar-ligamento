"""Entrenamiento y evaluación para «Ligamento» (Fase 0+).

Loop AdamW con warmup+clip (R4/R5). Evaluación de capacidad por carga con acc@1 y acc@k
(la distinción top-1 vs listwise de P1). Incluye un smoke de S0.1 (softmax reproduce MQAR).

Uso: python entrenar.py smoke    # chequeo S0.1 rápido
"""
import sys, time
import numpy as np
import jax, jax.numpy as jnp
from functools import partial
import optax

from datos import gen_mqar, gen_overwrite, PAD, IGNORE, V0, NV, V_E001
import modelos
from modelos import forward, init_params, count_params


def _pad_to(x, y, T, voc=V_E001):
    B = x.shape[0]
    xp = np.full((B, T), voc.PAD, np.int32); yp = np.full((B, T), IGNORE, np.int32)
    xp[:, :x.shape[1]] = x; yp[:, :y.shape[1]] = y
    return xp, yp


def _bucket_T(T, t_max, n):
    """Longitud a la que paddear: T redondeado hacia arriba en una grilla de `n` tramos.

    El padding fijo a `t_max` desperdicia ~55% del cómputo: la secuencia real promedia 230
    tokens y se rellena siempre hasta 514. Recortarlo es MATEMÁTICAMENTE neutro —el modelo es
    estrictamente causal (tril en softmax, scan en delta, conv3 causal) y `loss_fn` enmascara
    por `y >= 0`, así que el relleno va detrás de todo token real y no puede influirlo.

    Se agrupa en buckets en vez de usar T exacto porque cada forma nueva dispara una
    recompilación de JIT; con n=8 se captura casi todo el ahorro con 8 compilaciones.

    OJO: neutro en aritmética exacta NO implica idéntico en float32. Cambiar la forma cambia
    el tiling que elige XLA y con él el orden de las reducciones. Ver test_bucketing.py: si la
    trayectoria diverge, activar esto obliga a reentrenar desde cero, no a seguir de un ckpt.
    """
    paso = -(-t_max // n)                      # techo de t_max/n
    return min(t_max, -(-T // paso) * paso)    # techo de T/paso, en pasos de `paso`


def loss_fn(params, x, y, kind):
    logits = forward(params, x, kind)
    mask = (y >= 0)
    yl = jnp.where(mask, y, 0)
    ce = optax.softmax_cross_entropy_with_integer_labels(logits, yl)
    loss = (ce * mask).sum() / mask.sum()
    acc = ((logits.argmax(-1) == yl) * mask).sum() / mask.sum()
    return loss, acc


def train(kind, steps, seed=0, batch=64, lr=3e-3, max_load=16, t_max=None, log_every=100):
    """Currículum: pasos impares T1 (carga uniforme en [2,max_load]); pares T2 (correctabilidad)."""
    rng = np.random.default_rng(seed)
    params = init_params(seed, kind)
    if t_max is None:
        t_max = 4 * max_load + 2      # cubre T2 (overwrite): 3L+2r+2 ≤ 4L+2 con r≤L/2·… (r=L//2)
    sched = optax.warmup_constant_schedule(0.0, lr, 100)
    opt = optax.chain(optax.clip_by_global_norm(1.0), optax.adamw(sched, weight_decay=0.01))
    state = opt.init(params)

    @partial(jax.jit, static_argnames='kind')
    def train_step(params, state, x, y, kind):
        (l, a), g = jax.value_and_grad(loss_fn, has_aux=True)(params, x, y, kind)
        up, state = opt.update(g, state, params)
        return optax.apply_updates(params, up), state, l, a

    t0, hist = time.time(), []
    for s in range(1, steps + 1):
        if s % 2 == 0:
            L = int(rng.integers(4, max_load + 1))
            x, y, _ = gen_overwrite(rng, batch, L, r=max(1, L // 2))
        else:
            L = int(rng.integers(2, max_load + 1))
            x, y = gen_mqar(rng, batch, L)
        xp, yp = _pad_to(x, y, t_max)
        params, state, l, a = train_step(params, state, jnp.array(xp), jnp.array(yp), kind)
        if s % log_every == 0 or s == 1:
            l, a = float(l), float(a)
            hist.append({'step': s, 'loss': round(l, 4), 'acc': round(a, 4)})
            print(f'[{kind}] step {s:5d} loss {l:.4f} acc {a:.4f} ({time.time()-t0:.0f}s)', flush=True)
    return params, hist


def eval_capacity(params, kind, loads, seed=1234, batch=64, reps=4, topk=(1, 4, 16), voc=V_E001):
    """acc@k por carga sobre T1. Devuelve {L: {k: acc}}."""
    rng = np.random.default_rng(seed)
    fwd = jax.jit(partial(forward, kind=kind))
    out = {}
    for L in loads:
        accs = {k: [] for k in topk}
        for _ in range(reps):
            x, y = gen_mqar(rng, batch, L, voc=voc)
            t_max = 3 * L + 2
            xp, yp = _pad_to(x, y, t_max, voc=voc)
            logits = np.array(fwd(params, jnp.array(xp)))            # (B,T,VOCAB)
            m = yp >= 0
            # restringir a columnas de valor del vocab para la lectura (V0..V0+NV)
            val_logits = logits[..., voc.V0:voc.V0 + voc.NV]
            order = np.argsort(-val_logits, axis=-1)                  # top índices (0..voc.NV-1)
            true = np.where(m, yp - voc.V0, -1)
            for k in topk:
                topk_idx = order[..., :k]
                hit = (topk_idx == true[..., None]).any(-1)
                accs[k].append((hit * m).sum() / m.sum())
        out[L] = {k: float(np.mean(v)) for k, v in accs.items()}
    return out


def _val_acc(params, kind, val_loads=(64, 96, 128), seed=7777, batch=64, reps=2, voc=V_E001):
    """Val-acc para el criterio de convergencia: media de acc@1 sobre las cargas discriminantes."""
    cap = eval_capacity(params, kind, loads=list(val_loads), seed=seed, reps=reps, topk=(1,), voc=voc)
    return float(np.mean([cap[L][1] for L in val_loads]))


def train_resumable(cond, seed, target_steps, ckpt_path, max_load=128, lr=3e-3, batch=64,
                    val_loads=(64, 96, 128), val_every=500, log_every=500, n_buckets=None,
                    voc=V_E001, parar_al_converger=False, tol_conv=0.005):
    """Entrena hasta target_steps reanudando desde ckpt_path si existe (params + opt_state + rng + step +
    val_hist). Evalúa val-acc cada `val_every` pasos. Guarda checkpoint al terminar. Determinista por semilla:
    train_resumable(...,N) == entrenar de corrido hasta N (mismos batches y estado). Devuelve (params, val_hist).

    `n_buckets` agrupa la longitud de secuencia en vez de paddear siempre a 4*max_load+2 (ver _bucket_T).
    Por defecto None = comportamiento histórico, para no alterar nada de lo ya corrido. El sorteo de los
    batches NO depende de esto: el rng se consume antes del padding, así que activarlo no cambia ni un dato."""
    import pickle, os as _os
    t_max = 4 * max_load + 2
    sched = optax.warmup_constant_schedule(0.0, lr, 100)
    opt = optax.chain(optax.clip_by_global_norm(1.0), optax.adamw(sched, weight_decay=0.01))

    @partial(jax.jit, static_argnames='kind')
    def train_step(params, state, x, y, kind):
        (l, a), g = jax.value_and_grad(loss_fn, has_aux=True)(params, x, y, kind)
        up, state = opt.update(g, state, params)
        return optax.apply_updates(params, up), state, l, a

    if _os.path.exists(ckpt_path):
        with open(ckpt_path, "rb") as f:
            ck = pickle.load(f)
        params = jax.tree_util.tree_map(jnp.asarray, ck["params"])
        state = jax.tree_util.tree_map(jnp.asarray, ck["opt_state"])
        rng = np.random.default_rng(); rng.bit_generator.state = ck["rng_state"]
        start, val_hist = ck["step"], ck["val_hist"]
        if start >= target_steps:
            return params, val_hist
    else:
        params = init_params(seed, cond, vocab=voc.VOCAB)
        state = opt.init(params)
        rng = np.random.default_rng(seed)
        start, val_hist = 0, []

    t0 = time.time()
    paso_alcanzado = target_steps
    for s in range(start + 1, target_steps + 1):
        if s % 2 == 0:
            L = int(rng.integers(4, max_load + 1)); x, y, _ = gen_overwrite(rng, batch, L, r=max(1, L // 2), voc=voc)
        else:
            L = int(rng.integers(2, max_load + 1)); x, y = gen_mqar(rng, batch, L, voc=voc)
        T = t_max if n_buckets is None else _bucket_T(x.shape[1], t_max, n_buckets)
        xp, yp = _pad_to(x, y, T, voc=voc)
        params, state, l, a = train_step(params, state, jnp.array(xp), jnp.array(yp), cond)
        if s % val_every == 0:
            va = _val_acc(params, cond, val_loads=val_loads, voc=voc)
            val_hist.append({"step": s, "val_acc": va})
            print(f"[{cond} s{seed}] step {s:5d} val_acc {va:.4f} ({time.time()-t0:.0f}s)", flush=True)
            # E-005 §4: la calibración corta al converger en vez de gastar el tope entero.
            # Apagado por defecto: las campañas de E1 corren hasta target_steps como siempre.
            if parar_al_converger and converged(val_hist, s, window=val_every, tol=tol_conv):
                paso_alcanzado = s
                print(f"[{cond} s{seed}] CORTE POR CONVERGENCIA en {s} "
                      f"(mejora < {tol_conv} en los ultimos {val_every} pasos)", flush=True)
                break
    # guardar checkpoint (numpy para portabilidad del pickle)
    ck = {"params": jax.tree_util.tree_map(np.asarray, params),
          "opt_state": jax.tree_util.tree_map(np.asarray, state),
          "rng_state": rng.bit_generator.state, "step": paso_alcanzado, "val_hist": val_hist}
    with open(ckpt_path, "wb") as f:
        pickle.dump(ck, f)
    return params, val_hist


def converged(val_hist, target_steps, window=500, tol=0.005):
    """Criterio D-004: mejora de val-acc < 0.5 pts en la ventana de los últimos `window` pasos, en target_steps."""
    at = {h["step"]: h["val_acc"] for h in val_hist}
    if target_steps not in at or (target_steps - window) not in at:
        return None
    return (at[target_steps] - at[target_steps - window]) < tol


def eval_overwrite(params, kind, L=32, seed=4321, batch=64, reps=4, voc=V_E001):
    """Correctabilidad (T2): acc@1 sobre las claves REASIGNADAS (responder el valor nuevo)."""
    from datos import gen_overwrite
    rng = np.random.default_rng(seed)
    fwd = jax.jit(partial(forward, kind=kind))
    accs = []
    for _ in range(reps):
        x, y, upd = gen_overwrite(rng, batch, L, r=L // 2, voc=voc)
        t_max = 4 * L + 2
        xp, yp = _pad_to(x, y, t_max, voc=voc)
        um = np.zeros_like(yp, dtype=bool); um[:, -L:] = upd
        logits = np.array(fwd(params, jnp.array(xp)))
        pred = logits[..., voc.V0:voc.V0 + voc.NV].argmax(-1)
        true = np.where(yp >= 0, yp - voc.V0, -1)
        m = (yp >= 0) & um
        accs.append(((pred == true) & m).sum() / max(m.sum(), 1))
    return float(np.mean(accs))


def smoke():
    """S0.1: softmax debe reproducir MQAR (>95% a L=8) y degradarse suavemente."""
    print("=== SMOKE S0.1 · softmax en T1 (arquitectura §5, vocab E-001) ===")
    params, _ = train('softmax', steps=800, seed=0, max_load=16, lr=3e-3, log_every=200)
    print(f"params del modelo softmax: {count_params(params):,}")
    res = eval_capacity(params, 'softmax', loads=[8, 16, 32], reps=3)
    for L, d in res.items():
        print(f"  L={L:3d}  acc@1={d[1]:.3f}  acc@4={d[4]:.3f}  acc@16={d[16]:.3f}")
    ok = res[8][1] > 0.95
    print("S0.1:", "PASA ✓" if ok else "NO PASA ✗", f"(softmax acc@1 L=8 = {res[8][1]:.3f}, umbral 0.95)")
    return ok


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "smoke":
        smoke()
    else:
        print("uso: python entrenar.py smoke")
