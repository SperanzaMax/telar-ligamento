# Desviaciones — «Ligamento» (registro operativo, R0.4)

Cada entrada: fecha, motivo, alcance. Se registra **antes** de mirar los resultados afectados.

---

## D-006 · 2026-08-06 · Erratas del veredicto R4 y alcance real del corte por convergencia

Entrada **append-only**: no modifica ningún artefacto congelado. `verificar_anclas.py --requiere E-005`
verde antes y después.

### (a) El texto de R4 no cubre el caso que efectivamente ocurrió

El veredicto emitido dice *«el tope se agota con la bisección ABIERTA»*, pero el registro técnico de la
corrida del 2026-08-06 tiene `biseccion_cerrada: true`: en E-a la bisección **cerró** y ninguna carga
entró en la banda. Lo que impidió declarar R3 fue que el **espacio de escalones quedó incompleto** —E-b
no se corrió—, no una bisección abierta.

La lógica de `decidir()` es **correcta**: sin E-b corrido no puede declarar R3, porque R3 exige
«bisección cerrada en **ambos** escalones», y su única salida restante es R4. Lo que no cubre el caso es
la **redacción** del veredicto. Se deja constancia para revisores; el artefacto no se toca.

### (b) Causa raíz de que E-b no corriera: el costo por paso se subestimó un 44 %

No es un ítem separado del anterior, es su causa. El bench del 2026-08-05 dio 1,815 s/paso para E-a;
la corrida real midió **2,60 s/paso**. Con esa corrección, el plan de E-b pasa a ≈4,9 h de estación de
trabajo contra un tope congelado de 3 h por escalón: **no entraba, y por eso el espacio de escalones
quedó incompleto**. Todo presupuesto futuro usa el número medido, no el del bench.

### (c) El corte por convergencia se dispara dentro de mesetas — alcance acotado por medición

En el sondeo exploratorio de `d` (ver `resultados/sondeo_d/RESUMEN_sondeo_d_20260806.json`), `d=8` fue
rotulado «convergido» a nivel azar con ventana 250 / tol 0,005; reentrenado sin corte estuvo **750 pasos
en meseta y después despegó** hasta 0,40. Es una instancia fresca e independiente del error que la
auditoría del 2026-07-27 halló en el borrador del preprint, y la razón de ser de `stoppower`.

**Nota importante sobre el alcance, porque la lectura fácil es errónea.** El criterio de D-004 usa
ventana **500**, no 250 — pero la meseta observada duró **750 pasos**, así que *también* se habría
disparado dentro de ella. La inmunidad de las campañas firmadas **no** viene del criterio, y las dos
razones que suelen darse son inexactas:

- «E1 usó R5 (paciencia 2000)» — **falso**: D-003 registra que R5 no se implementó; Fase 0 corrió con
  pasos fijos y el criterio de D-004.
- «se cerró con oráculo closed-form» — **cierto para TELAR-03, no para E1**.

La razón que sí se sostiene, y es verificable, es que el patrón **sólo puede afectar corridas cortadas
lejos del techo**: un modelo en meseta a nivel azar tiene a dónde despegar, uno saturado no. Chequeo
dirigido sobre los `N` de la campaña E1 (hecho, no inferido):

| condición | N final | qué decidió el N | expuesta |
|---|---|---|---|
| `softmax` | 2500 en 8/8 | el criterio de D-004 | **no** — acc@1 ∈ [0,9995 · 1,0000], en el techo: no hay despegue posible |
| `delta` | 10000 en 8/8 | tope duro | no — el criterio no decidió |
| `mix22` | 10000 (fase B) | tope duro | no — el criterio no decidió |

Ninguna corrida firmada queda expuesta. **No se revisan E1 ni TELAR-03.**

**Lección que sí se adopta, y es más fuerte que subir topes:** no se usa corte por meseta de accuracy en
esta familia de tareas —ningún tope arregla un criterio que se dispara adentro de la meseta—. El criterio
para regímenes de baja capacidad es **mejor checkpoint por validación**, con grilla pre-declarada,
selección en validación y reporte en test held-out, más un **flag de divergencia**: se registran pico,
paso del pico y valor final, y si el final cae por debajo del pico menos k·SD el run se rotula
*inestable* en vez de tomarse el pico en silencio. Sin ese flag, «mejor checkpoint» es una puerta
trasera. Nada de esto es aflojamiento: es explicitar lo que R5 ya pretendía.

---

## D-005 · 2026-08-02 · El informe se pronunciaba sobre una campaña a medias (defecto del generador)

**Qué.** Todos los chequeos de estado del agregador leían `runs[0]["steps"]` —la semilla 0— como si
representara a la condición entera. La fase B extiende **una semilla por vez**, así que apenas
`mix22 seed0` llegó a 10000, la condición entera pasó por extendida. En el informe del 2026-08-02
(con 3/8 semillas extendidas) eso produjo cuatro afirmaciones falsas:

1. **B1-ter emitió veredicto** («sin degradación material»), cuando la enmienda E-003′ lo declaró
   sobre la extensión **completa**. La guarda de «extensión EN CURSO» existía pero no disparaba.
2. Peor que el pronunciamiento prematuro: la media apareada se calcula sobre las 8 semillas, y las
   que todavía no se movieron aportan una caída de **exactamente 0 por construcción**. Verificado en
   test: una degradación real de 0,03 (> umbral 0,0200) en las 3 extendidas se promedia a
   3·0,03/8 = **0,011 y queda absuelta**. El defecto no sólo hablaba de más: podía **enmascarar una
   degradación material** y salvar a PS-1 de su propio fusible.
3. La columna `N` de la tabla primaria decía `10000` para una fila que promedia checkpoints de 2500,
   7500 y 10000; y el encabezado sacó a `mix22` de la lista de «NO extendidas».
4. La línea de concordancia declaraba las tablas **CONCORDANTES** con 5/8 pares que siguen siendo
   copias bit a bit (`cerrar_faseA` congela por `shutil.copyfile`) — el mismo defecto que la
   auditoría del 27-jul detectó y que se creía resuelto.

**Qué se cambió.** Sólo los **rótulos y las guardas**: todas leen ahora los `steps` de **todas** las
semillas (helpers `pasos`, `celda_n`, `aviso_n_heterogeneo` en `analisis_e1.py`). El aviso de N
heterogéneo, que existía en `regenerar_informe_local.py`, se portó al runner de producción, que no lo
tenía. **No se tocó ningún umbral, criterio ni veredicto del prereg.** B1-ter conserva su 0,0200 y su
consecuencia automática; ahora simplemente no se pronuncia hasta que las 8 semillas estén a N_common.

**Dirección de conveniencia.** El veredicto que este arreglo **retira** era el favorable («sin
degradación material», que dejaba PS-1 intacto). El arreglo va contra la conveniencia del ejecutor.

**Alcance.** No afecta datos ni checkpoints: los 48 JSON no se tocan. Afecta cualquier informe
emitido durante la fase B —el del 2026-08-02 queda **anulado en sus veredictos de B1-ter y de
concordancia**— y protege el caso en que la campaña se corte antes de completar las 8 semillas.
Cubierto por `test_agregador_e1.py`, escenario «extensión HETEROGÉNEA» (falla 7/7 contra el código
previo). Suite completa verde.

## D-003 · 2026-07-22 · R5 (early stopping) no implementado en la campaña S0.9 — pasos fijos

**Qué.** El runner `fase0_s09.py` corrió con **STEPS=2500 fijos, sin el early stopping por validación** que
manda R5 («paciencia 2000, tope 20 000»). Detectado al analizar la curva de entrenamiento de `delta_seed0`:
train acc 0.8411 (step 2000) → 0.9353 (step 2500) — **delta aún subía fuerte, no convergió** a 2500. En cambio
softmax converge holgado antes de 2500 (queda como está).

**Consecuencia.** La eval por carga de delta a 2500 (L128 acc@1=0.755, carga de evaluación preliminar L96) es un
**snapshot no convergido = lower bound de la capacidad de delta**. No interpretable como el plateau real ni como
ancla del prereg C3-vs-C2.

**Estado:** corregida por D-004. La foto a 2500 se conserva como snapshot documentado, no como resultado principal.

## D-004 · 2026-07-22 · Corrección: extensión uniforme hasta convergencia (criterio explícito)

**Fechada ANTES de mirar la eval por carga de las semillas extendidas** (requisito de §0.4).

**Criterio de convergencia (pre-registrado acá):** una condición/semilla converge cuando la **mejora de accuracy
de validación es < 0.5 puntos en la ventana de los últimos 500 pasos**. Val-acc = media de acc@1 sobre las cargas
discriminantes {64, 96, 128} en un set de validación con semilla propia.

**Procedimiento (uniforme, nunca por semilla individual):**
1. Completar las 8 semillas de delta a 2500 (consistencia de la pasada actual). Softmax queda a 2500 (cumple el
   criterio).
2. Fase de extensión (`fase0_s09_extend.py`), en **bloques de +2500 pasos aplicados a TODAS las semillas de delta
   por igual**, hasta que **todas** cumplan el criterio o se alcance el **tope duro de 10 000 pasos**.
3. **Resultado principal = la tabla convergida** (todas al mismo N, `delta_conv_seed*.json`). La foto a 2500
   (`delta_seed*.json`) = snapshot documentado.

**Nota de implementación (registrada al construir el mecanismo).** El runner base `fase0_s09.py` guardó solo
métricas, **no los pesos**, así que el **primer bloque de la extensión re-entrena delta desde 0** (re-computa los
2500 ya hechos + 2500 nuevos); los bloques siguientes (5000→7500→…) **sí reanudan** desde checkpoint de pesos.
La reanudación se validó **determinista bit-a-bit** (`max|Δ| = 0.00e+00` reanudado vs. corrido), así que el
re-cómputo produce exactamente los mismos primeros 2500 que el snapshot base — sin inconsistencia, solo costo.
*(Lección: los runners de E1/TELAR-03 guardan checkpoint de pesos desde el arranque — ya en `train_resumable`.)*

**Motivo y costo real.** El 0.755@L128 y la carga de evaluación del prereg C3-vs-C2 solo son interpretables
anclados a números **convergidos**. Costo real (mayor que la estimación inicial de ~5 h, que asumía reanudación
desde 2500): **~10 h de T4 si delta converge a 5000 · ~15 h si a 7500** (por el re-cómputo del primer bloque).
Una noche larga, contra el costo de que la primera tabla real de Ligamento nazca con un asterisco en su cifra más
importante.

**Para el futuro (fuera de esta corrección):** la restauración plena de R5 (early stopping con paciencia, tope
10k) queda para E1 real y TELAR-03 Fase 2. Consenso de los tres.

---

## D-002 · 2026-07-22 · Presupuesto de parámetros por encima de lo declarado (observación, NO bloqueante)

**Qué.** La arquitectura §5 tal como está especificada (d_model=64, H=4, 4 bloques, 4 proyecciones D×D
por bloque, FFN hidden 192) produce un modelo softmax de **192 453 parámetros**, por encima del rango
«≈100k–150k» declarado en §3/§5. Desglose: bloques ≈167 040 (4 × ~41 760) + vocab (E-001) 25 413.
El grueso del exceso es la arquitectura misma (~167k sin vocab), no la enmienda E-001.

**Estado:** ABIERTO como observación; **no bloquea nada, no se corrige** (la arquitectura está congelada).
Es una inconsistencia pre-existente entre el presupuesto declarado y la arquitectura declarada, detectada al
instanciar el modelo. **R2 (params ±5% ENTRE condiciones) no se ve afectado**: es un criterio relativo, y
el embedding/FFN/proyecciones son comunes a C1..C4; la diferencia entre condiciones viene de las cabezas.
El presupuesto absoluto es una guía de §3, no un criterio de veredicto. Se documenta para trazabilidad y para
que el informe reporte el conteo real (S0.6 exige la tabla de params por condición de todos modos).

---

## D-001 · 2026-07-22 · CONFLICTO DE ESPECIFICACIÓN (bloqueante de Fase 0, frenado por §0.5)

**Estado:** **RESUELTO 2026-07-22 por la enmienda E-001 (opción a, ratificada por ANON-AUTHOR).** Ver
`protocolo/FREEZE_v1.0.md` § «Enmiendas post-freeze → E-001». Resolución: vocab de T1–T4 = 128 claves +
64 valores + 5 especiales (BOS/SEP/PAD/CTX_A/CTX_B) = **197**; params de vocab 25 413, compartidos e
idénticos en toda condición → R2 intacto; +13 029 params uniformes vs. lectura literal ≤96. Causa
registrada con nombre: **defecto de redacción de D2 (Fable 5), detectado por el ejecutor en
implementación** antes de correr. El protocolo hasheado NO se tocó (SHA-256 `2f8ebb82…` intacto).

### Registro original (se conserva)

**Qué.** Tensión interna en el protocolo congelado v1.0 entre D2 y §4:
- **§6 / D2** extienden T1 a `L ∈ {8, 16, 32, 64, 96, 128}` y definen la carga de evaluación de
  P1.1 como la menor L donde C1 (softmax) cae < 95%.
- **§4** especifica `vocabulario ≤ 96 tokens` y T1 con **claves sin repetir** (MQAR estándar,
  port de TELAR-01 `gen_batch`: `argsort(random)[:, :n]` → n claves distintas de un pool de NK).

**Por qué es infactible bajo lectura literal.** Con claves únicas, L=128 requiere ≥128 símbolos de
clave distintos; L=96 requiere ≥96. Pero el vocab total (claves + valores + BOS/SEP/PAD) es ≤96.
TELAR-01 usaba NK=64 claves + NV=64 valores + 3 especiales = 131 y topaba justo a L=64. No hay forma
de muestrear 96 ni 128 claves únicas dentro de un vocab de 96 que además aloje valores y especiales.
→ Las dos cargas nuevas de D2 (96, 128) — las que importan para decidir si softmax satura — no se
pueden instanciar con la definición de tarea de §4.

**Origen probable.** El `vocab ≤ 96` viene del régimen L≤64 de v0.1/v0.2 (TELAR-01). D2 se agregó en
v0.3.1→v1.0 y extendió las cargas sin reconciliar §4. Inconsistencia introducida tarde; detectada al
implementar los generadores (antes de correr una sola semilla — el orden correcto).

**Por qué se frena y no se improvisa.** El protocolo está pre-registrado y firmado (tag
`ANON-TAG`). Elegir la resolución cambia el diseño de la tarea y podría sesgar P1.1;
§0.5 obliga a frenar y reportar. La resolución debe pre-registrarse como enmienda antes de correr.

**Opciones candidatas (para que decidan ANON-AUTHOR/Fable5 — el ejecutor NO elige):**
- **(a) Separar el espacio de claves del de valores** y relajar el «≤96» a lo que D2 exige:
  claves de un pool ≥128, valores en un rango propio (p.ej. ≤64), + especiales. Enmienda mínima,
  no toca ninguna predicción, solo el número de §4. Es la más limpia. Riesgo: un vocab de claves
  mayor cambia levemente la dificultad de embedding, pero igual para todas las condiciones de E1
  (no confunde P1.1). **Recomendación tentativa del ejecutor**, sujeta a ratificación.
- **(b) Claves compuestas (bigramas)**: cada clave = 2 tokens de un vocab chico → 96² claves. Cambia
  el layout de secuencia y los largos; más invasivo; interactúa con la igualación de largo (O4) y con
  el conteo de FLOPs. Menos preferible.
- **(c) Acotar L al máximo que el vocab permita** (no extender a 96/128). Rechaza de facto a D2:
  si el vocab corta L antes de que softmax caiga, la pregunta de D2 («¿satura el baseline?») queda
  sin responder. Va contra el objetivo mismo de D2. No recomendada.

**Alcance.** Bloquea la instanciación de T1 (E1) a L∈{96,128} y, por lo tanto, S0.9 (carga de
evaluación de E1) y la corrida de C1. NO bloquea T2 (correctabilidad, L≤64), ni T3/T4/T5, ni la
medición de ruido/márgenes de las otras familias (P2.x, P3.x, P4.x). Se puede avanzar con el resto de
la infraestructura mientras se decide D-001.

## D-007 — El campo `veredicto` del registro de E-b dice R4, y el veredicto real es R3

**2026-08-08, hallada en la revisión en frío del paper.**

`resultados/calibracion/calibracion_rbanda_E-b.json` lleva escrito, en su campo `veredicto`,
el texto de **R4** («DECISIÓN SUSPENDIDA: el tope se agotó con la bisección ABIERTA … Leer R4
como R3 sería convertir una restricción de crédito en un hallazgo»). Ese texto es un remanente
del estado anterior a la corrida: **contradice al propio archivo**, que en el mismo objeto
registra `biseccion_cerrada: true` para E-b.

**El veredicto de la escalera no vive en ese campo.** Lo emite `decidir_escalera.py` cuando se
lo alimenta con los **dos** registros, y su salida —verificada de nuevo hoy— es:

```
R3 — FRONTERA INALCANZABLE: ningún escalón cumple la banda y la bisección cerró en ambos.
rama=R3 · régimen elegido=None
```

**Qué se hace:** nada sobre el artefacto. El JSON es un registro de corrida y no se toca; el
campo quedó mal escrito pero ningún número depende de él. Se documenta acá porque un lector
que abra ese archivo antes que el informe va a leer un R4 y sospechar que el paper leyó R4
como R3 — que es exactamente lo que ese texto prohíbe. No ocurrió: el R3 sale del decisor con
la escalera completa, y `CIERRE_CALIBRACION_20260806.md` ya lo dejaba reproducible con el
comando exacto.

**Riesgo residual:** si en una campaña futura se lee ese campo por programa en vez de correr el
decisor, se obtiene el veredicto equivocado. Conviene que el runner deje de escribirlo, o que
lo escriba como `veredicto_del_escalon` para que no se confunda con el de la escalera.
