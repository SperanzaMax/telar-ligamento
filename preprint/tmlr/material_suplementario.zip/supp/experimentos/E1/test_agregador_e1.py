"""Test de humo del agregador de E1 (`aggregate`) con datos sintéticos, sin JAX ni GPU.

Inyecta stubs de los módulos que solo hacen falta para ENTRENAR (jax, entrenar, modelos, fase0_s09),
escribe JSONs de semilla como los que produce la campaña, y verifica que el informe sale con los
veredictos correctos — incluida la regla de discordancia del Anexo B3.

Uso: python3 experimentos/E1/test_agregador_e1.py
"""
import json
import os
import shutil
import sys
import tempfile
import types

import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
LOADS = [8, 16, 32, 64, 96, 128]
fallos = []


def check(nombre, cond, extra=""):
    print(f"  {'✓' if cond else '✗'} {nombre}{(' — ' + str(extra)) if extra else ''}")
    if not cond:
        fallos.append(nombre)


def _stubs():
    """Módulos falsos: el agregador no los usa, pero e1_runner los importa al cargarse."""
    jax = types.ModuleType("jax")
    jax.config = types.SimpleNamespace(update=lambda *a, **k: None)
    jax.devices = lambda: [types.SimpleNamespace(platform="cpu", device_kind="stub")]
    sys.modules["jax"] = jax
    entrenar = types.ModuleType("entrenar")
    for n in ("train_resumable", "converged", "eval_capacity", "eval_overwrite"):
        setattr(entrenar, n, lambda *a, **k: None)
    sys.modules["entrenar"] = entrenar
    modelos = types.ModuleType("modelos")
    modelos.count_params = lambda p: 0
    sys.modules["modelos"] = modelos
    s09 = types.ModuleType("fase0_s09")
    s09.device_info = lambda: {"device_kind": "stub"}
    s09.notify = lambda *a, **k: None
    sys.modules["fase0_s09"] = s09


def escribir_semilla(d, cond, seed, curva, t2, steps, paso_conv, sufijo=""):
    out = {"exp": "E1", "cond": cond, "seed": seed, "steps": steps, "converged": True,
           "paso_conv_propio": paso_conv, "params": 192453, "device": {"device_kind": "stub"},
           "capacity": {str(L): {"1": float(a), "4": float(min(1.0, a + .1)),
                                 "16": float(min(1.0, a + .2))} for L, a in zip(LOADS, curva)},
           "T2": {str(L): float(v) for L, v in t2.items()},
           "val_hist": [{"step": 500, "val_acc": .5}], "wall_s": 1.0}
    json.dump(out, open(os.path.join(d, f"e1_{cond}_seed{seed}{sufijo}.json"), "w"), indent=1)


def escenario(d, rescate_primaria, rescate_secundaria, n_seeds=8, semilla=0):
    """Escribe C1/C2/C3 con el rescate pedido en cada tabla."""
    rng = np.random.default_rng(semilla)
    base = np.array([1.0, 1.0, .999, .974, .887, .773])
    for s in range(n_seeds):
        ruido = rng.normal(0, .004, 6)
        c2 = np.clip(base + ruido, 0, 1)
        escribir_semilla(d, "softmax", s, np.ones(6), {32: 1.0, 96: 1.0, 128: 1.0}, 5000, 2000)
        escribir_semilla(d, "softmax", s, np.ones(6), {32: 1.0, 96: 1.0, 128: 1.0}, 2500, 2000, "_propio")
        escribir_semilla(d, "delta", s, c2, {32: .89 - .5 * (c2[5] - .773), 96: .60, 128: .45},
                         5000, 2500 + 500 * s)
        escribir_semilla(d, "delta", s, c2, {32: .89 - .5 * (c2[5] - .773), 96: .60, 128: .45},
                         5000, 2500 + 500 * s, "_propio")
        for suf, resc in (("", rescate_primaria), ("_propio", rescate_secundaria)):
            c3 = np.clip(c2 + np.where(np.array(LOADS) >= 96, resc, 0), 0, 1)
            escribir_semilla(d, "mix22", s, c3, {32: .93, 96: .70, 128: .55},
                             5000 if not suf else 2500, 2000, suf)


def correr_aggregate(d):
    os.environ["RESULTS_DIR"] = d
    os.environ["CONDS"] = "delta,softmax,mix22"
    os.environ["N_SEEDS"] = "8"
    for m in list(sys.modules):
        if m in ("e1_runner", "analisis_e1"):
            del sys.modules[m]
    sys.path.insert(0, AQUI)
    import e1_runner
    e1_runner.aggregate()
    return open(os.path.join(d, "E1_informe.md"), encoding="utf-8").read()


_stubs()
print("=== Agregador de E1 · escenario CONCORDANTE (rescate real en ambas tablas) ===")
d = tempfile.mkdtemp()
escenario(d, rescate_primaria=0.10, rescate_secundaria=0.10)
inf = correr_aggregate(d)
check("carga de evaluación instanciada en L96 desde C2", "carga de evaluación (desde C2 convergida): L96" in inf)
check("declara N_common", "N_common = 5000" in inf, [l for l in inf.split("\n") if "N_common" in l][:1])
check("emite las dos tablas", "Tabla PRIMARIA" in inf and "Tabla SECUNDARIA" in inf)
check("PS-1 confirma con tablas concordantes", "**VEREDICTO: CONFIRMA**" in inf and "CONCORDANTES" in inf)
check("PS-2 reporta la posición f", "f = (C3−C2)/(C1−C2)" in inf)
check("PS-4(i) confirma con la curva del snapshot", "mediana(L₀) = 64" in inf)
check("PS-5 aplica el fallback a L32 (T2@96 = 0.60 tiene SD nula)", "T2 primaria: **L32**" in inf)
check("el fallback declara la condición cross-carga", "CROSS-CARGA" in inf)
check("P1.2 y P1.3 del madre presentes", "**P1.2**" in inf and "**P1.3**" in inf)
shutil.rmtree(d)

print("\n=== escenario DISCORDANTE (rescate solo en la tabla primaria) ===")
d = tempfile.mkdtemp()
escenario(d, rescate_primaria=0.10, rescate_secundaria=-0.05)
inf = correr_aggregate(d)
check("PS-1 → «no concluyente por sensibilidad al presupuesto»",
      "NO CONCLUYENTE POR SENSIBILIDAD AL PRESUPUESTO" in inf)
check("y lo marca como DISCORDANTES", "DISCORDANTES" in inf)
check("no oculta que la primaria confirmaba", "primaria (N_common): confirma" in inf)
shutil.rmtree(d)

print("\n=== escenario SIN rescate (C3 = C2) ===")
d = tempfile.mkdtemp()
escenario(d, rescate_primaria=0.0, rescate_secundaria=0.0)
inf = correr_aggregate(d)
check("PS-1 falsa cuando no hay rescate", "**VEREDICTO: FALSA**" in inf)
shutil.rmtree(d)

print("\n=== escenario FASE B SIN CORRER (E-003′/B1-bis: mismo checkpoint en ambas tablas) ===")
d = tempfile.mkdtemp()
escenario(d, rescate_primaria=0.10, rescate_secundaria=0.10)
# La fase B no corrió: `cerrar_faseA` copió la primaria, así que mix22 queda a 2500 en las DOS.
for s in range(8):
    shutil.copyfile(os.path.join(d, f"e1_mix22_seed{s}_propio.json"),
                    os.path.join(d, f"e1_mix22_seed{s}.json"))
inf = correr_aggregate(d)
check("no afirma que las tablas concuerdan cuando son el mismo checkpoint",
      "CONCORDANTES" not in inf)
check("declara que B3 no se ejecutó", "B3 no se ejecutó" in inf)
check("el encabezado marca la condición no extendida en vez de decir «todas a N_common»",
      "NO extendidas, a su N real: mix22" in inf and "todas las condiciones a N_common" not in inf)
shutil.rmtree(d)

print("\n=== B1-ter: el fusible anula PS-1 aunque las dos tablas concuerden ===")
# mix22 se degrada 0.03 (> umbral 0.02) al extender, pero sigue muy por encima de delta:
# las dos tablas confirman igual, así que B3 NO dispara — B1-ter sí tiene que dispararlo.
d = tempfile.mkdtemp()
escenario(d, rescate_primaria=0.10, rescate_secundaria=0.13)
inf = correr_aggregate(d)
check("B3 por sí sola no habría disparado (ambas tablas confirman)",
      "primaria (N_common): confirma" in inf and "secundaria (convergencia propia): confirma" in inf)
check("B1-ter detecta la degradación material", "DEGRADACIÓN MATERIAL" in inf)
check("y el veredicto de PS-1 queda anulado",
      "**VEREDICTO: NO CONCLUYENTE POR SENSIBILIDAD AL PRESUPUESTO**" in inf)
check("declara que lo impuso B1-ter", "impuesto por B1-ter" in inf)
shutil.rmtree(d)

print("\n=== B1-ter: una caída MENOR al umbral se reporta pero no cambia el veredicto ===")
d = tempfile.mkdtemp()
escenario(d, rescate_primaria=0.10, rescate_secundaria=0.11)   # cae 0.01 < umbral 0.02
inf = correr_aggregate(d)
check("no dispara con caída sub-umbral", "DEGRADACIÓN MATERIAL" not in inf)
check("pero informa la magnitud igual", "sin degradación material" in inf)
check("PS-1 conserva su veredicto", "**VEREDICTO: CONFIRMA**" in inf)
shutil.rmtree(d)

print("\n=== B1-ter: con la extensión A MITAD de camino NO se pronuncia ===")
# mix22 va por 5000 de un N_common de 10000, y ademas se degrado 0.03 (> umbral).
# El criterio se declaro sobre la extension COMPLETA: no debe disparar todavia.
d = tempfile.mkdtemp()
escenario(d, rescate_primaria=0.10, rescate_secundaria=0.13)
for s in range(8):                       # bajar mix22 de la primaria a 5000 (delta fija N_common=5000)
    r = os.path.join(d, f"e1_mix22_seed{s}.json")
    o = json.load(open(r)); o["steps"] = 3000; json.dump(o, open(r, "w"))
inf = correr_aggregate(d)
check("no dispara con la extensión incompleta", "DEGRADACIÓN MATERIAL" not in inf)
check("y dice que está en curso", "extensión EN CURSO" in inf)
check("PS-1 conserva su veredicto mientras tanto", "**VEREDICTO: CONFIRMA**" in inf)
shutil.rmtree(d)

print("\n=== B1-ter: extensión HETEROGÉNEA (unas semillas a N_common, otras no) NO se pronuncia ===")
# El caso real de la fase B: extiende UNA semilla por vez, así que hay un estado intermedio con
# seed0 ya en N_common y el resto sin tocar. Mirar `runs[0]["steps"]` daba por extendida a toda la
# condición, y la media apareada se diluía con las semillas quietas (caída 0 por construcción).
d = tempfile.mkdtemp()
escenario(d, rescate_primaria=0.10, rescate_secundaria=0.13)   # las extendidas caen 0.03 > umbral
for s in range(3, 8):                    # sólo 0,1,2 llegaron a N_common; 3..7 siguen en fase A
    r = os.path.join(d, f"e1_mix22_seed{s}.json")
    o = json.load(open(r)); o["steps"] = 2500; json.dump(o, open(r, "w"))
    shutil.copyfile(os.path.join(d, f"e1_mix22_seed{s}_propio.json"), r)
inf = correr_aggregate(d)
check("no dispara B1-ter con la extensión a medias", "DEGRADACIÓN MATERIAL" not in inf)
# Y tampoco absuelve: las 3 extendidas caen 0.03 (> umbral 0.02), pero promediadas con las 5
# quietas dan 3·0.03/8 = 0.011 < 0.02. Un veredicto acá ENMASCARA una degradación material real.
check("tampoco declara «sin degradación material» (la media diluida la enmascararía)",
      "sin degradación material" not in inf)
check("dice cuántas semillas van", "3/8 semillas a N_common" in inf)
check("la columna N muestra el rango, no el de la semilla 0", "2500–5000 ⚠" in inf)
check("avisa de N heterogéneo", "N HETEROGÉNEO dentro de una condición" in inf)
check("no declara las tablas CONCORDANTES", "CONCORDANTES" not in inf)
check("dice que B3 aún no es un chequeo completo",
      "5/8 semillas de C3 siguen con el mismo checkpoint" in inf)
check("el encabezado no da mix22 por extendida", "NO extendidas, a su N real" in inf
      and "mix22" in [l for l in inf.split("\n") if "NO extendidas" in l][0])
shutil.rmtree(d)

print("\n=== B1-ter: sin extensión corrida, el veredicto se imprime como «no aplica» ===")
d = tempfile.mkdtemp()
escenario(d, rescate_primaria=0.10, rescate_secundaria=0.10)
for s in range(8):
    shutil.copyfile(os.path.join(d, f"e1_mix22_seed{s}_propio.json"),
                    os.path.join(d, f"e1_mix22_seed{s}.json"))
inf = correr_aggregate(d)
check("imprime B1-ter aunque no aplique (no se silencia)", "B1-ter" in inf and "NO APLICA" in inf)
check("y dice por qué", "la extensión no corrió" in inf)
shutil.rmtree(d)

print("\n" + "=" * 60)
if fallos:
    print(f"✗ {len(fallos)} FALLO(S): " + "; ".join(fallos))
    sys.exit(1)
print("✓ AGREGADOR VERIFICADO — doble tabla, regla de discordancia y fallback de T2 funcionan.")
