# Supplementary material

Everything needed to reproduce every number in the paper. Author-identifying strings have
been replaced by `ANON-*` placeholders; nothing else was altered.

## Layout

```
protocolo/     frozen protocol, follow-up pre-registration, amendments, and their FREEZE
               companions (each carries the SHA-256 and the anchoring record)
src/           model, data generation, training loop, probes, analysis
experimentos/  runners per experiment, plus the decision procedures
resultados/    raw per-seed JSON for every condition, and the calibration records
desviaciones.md  log of every operational deviation, dated and justified
```

## Reproducing the headline numbers

Top-1 accuracy per condition lives in each `resultados/E1/e1_<cond>_seed<N>_propio.json`
under `capacity[<load>]["1"]` (`"1"` = top-1; `"4"` and `"16"` are the wider criteria).
The paired difference at the pre-registered evaluation load is the mean over seeds of
`mix22 − delta` at load 96. No project code is needed to check it: the standard library
suffices, which is how the independent re-implementation was written.

## The calibration verdict

The ladder verdict is **not** the `veredicto` field inside
`resultados/calibracion/calibracion_rbanda_E-b.json` — that field holds a stale string from
before the rung was run, and contradicts `biseccion_cerrada: true` in the same object (logged
as D-007 in `desviaciones.md`). The verdict is emitted by the frozen decision procedure when
given both records:

```
python experimentos/E1/decidir_escalera.py \
    resultados/calibracion/calibracion_rbanda.json \
    resultados/calibracion/calibracion_rbanda_E-b.json
```

which prints `rama=R3` — the branch reported in the paper.

## Verifying the pre-registration

Each `protocolo/FREEZE_*.md` records the SHA-256 of the artifact it governs, so
`sha256sum -c` against the corresponding file shows it was not modified. The hashes printed in
the paper match these files. The public anchors that carry the server-side timestamps are
withheld during review because they identify the author.
